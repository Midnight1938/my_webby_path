# Android Nougat update animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/stevn/pen/ZOKdjm](https://codepen.io/stevn/pen/ZOKdjm).

The new Android N firmware update animation (or a close approximation of it!)

All in CSS and HTML
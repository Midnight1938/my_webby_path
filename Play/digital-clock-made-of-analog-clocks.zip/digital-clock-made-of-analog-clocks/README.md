# Digital clock made of analog clocks

A Pen created on CodePen.io. Original URL: [https://codepen.io/robertochiaveri/pen/GXWZOK](https://codepen.io/robertochiaveri/pen/GXWZOK).

An experiment to see what would it look like to have a digital clock made of tiny analog clocks.

The logic is mainly in the SCSS: for each digit is defined a set of transforms for the clocks hands
Javascript merely builds the dom and fires up the loop function